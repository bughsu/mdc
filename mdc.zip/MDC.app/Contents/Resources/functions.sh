#!/bin/bash
# 共用函式:給 sync.sh 跟 GUI 控制面板(AppleScript,透過 do shell script 呼叫)共用
# 這個檔案只定義函式,不會自己執行任何動作,要被 source 進別的腳本才有作用

# GUI 面板透過 AppleScript 的 do shell script 執行,PATH 是精簡版,不含 Homebrew
# 路徑,先補上,不然明明裝過 brew/Squirrel 也會被誤判成沒裝
export PATH="/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/usr/local/sbin:$PATH"

RIME_DIR="$HOME/Library/Rime"
LAB="$HOME/rime_grammar_lab"
SQUIRREL_CUSTOM="$RIME_DIR/squirrel.custom.yaml"
BOPOMO_CUSTOM="$RIME_DIR/bopomo_onion.custom.yaml"
mkdir -p "$RIME_DIR"

find_squirrel_bin() {
  if [ -x "/Library/Input Methods/Squirrel.app/Contents/MacOS/Squirrel" ]; then
    echo "/Library/Input Methods/Squirrel.app/Contents/MacOS/Squirrel"
  elif [ -x "$HOME/Library/Input Methods/Squirrel.app/Contents/MacOS/Squirrel" ]; then
    echo "$HOME/Library/Input Methods/Squirrel.app/Contents/MacOS/Squirrel"
  fi
}

redeploy() {
  local bin
  bin="$(find_squirrel_bin)"
  if [ -n "$bin" ]; then
    "$bin" --reload
  fi
}

ensure_pyyaml() {
  python3 -c "import yaml" >/dev/null 2>&1 && return 0
  # 不同機器的 pip 版本支援的參數不一樣,依序試,裝到成功為止
  python3 -m pip install --break-system-packages --quiet pyyaml >/dev/null 2>&1
  python3 -c "import yaml" >/dev/null 2>&1 && return 0
  python3 -m pip install --user --quiet pyyaml >/dev/null 2>&1
  python3 -c "import yaml" >/dev/null 2>&1 && return 0
  python3 -m pip install --quiet pyyaml >/dev/null 2>&1
  python3 -c "import yaml" >/dev/null 2>&1
}

# 設定/取消某個 App 的中文輸入(ascii_mode: false = 允許打中文,true = 強制英文)
# 用法: set_ascii_mode <bundle_id> <true|false>
set_ascii_mode() {
  ensure_pyyaml
  python3 - "$SQUIRREL_CUSTOM" "$1" "$2" << 'PYEOF'
import sys, yaml

path, bundle_id, value = sys.argv[1], sys.argv[2], sys.argv[3] == "true"
try:
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
except FileNotFoundError:
    data = {}

data.setdefault("patch", {})
data["patch"].setdefault("app_options", {})
data["patch"]["app_options"].setdefault(bundle_id, {})
data["patch"]["app_options"][bundle_id]["ascii_mode"] = value

with open(path, "w", encoding="utf-8") as f:
    yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)
PYEOF
}

# 讀某個 App 目前的 ascii_mode 設定,印出 true/false/unset(從沒設過,視同 false 因為
# 我們同步時預設就會關掉強制英文)
get_ascii_mode() {
  ensure_pyyaml
  python3 - "$SQUIRREL_CUSTOM" "$1" << 'PYEOF'
import sys, yaml
path, bundle_id = sys.argv[1], sys.argv[2]
try:
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
except FileNotFoundError:
    data = {}
v = data.get("patch", {}).get("app_options", {}).get(bundle_id, {}).get("ascii_mode")
print("unset" if v is None else str(v).lower())
PYEOF
}

# 合併寫入/移除 bopomo_onion.custom.yaml 裡 patch 的某一個 key,不影響其他已經寫入的 key
# 用法: bopomo_patch_set <key路徑> <JSON值>  或  bopomo_patch_unset <key路徑>
bopomo_patch_set() {
  ensure_pyyaml
  python3 - "$BOPOMO_CUSTOM" "$1" "$2" << 'PYEOF'
import sys, json, yaml

path, key, value_json = sys.argv[1], sys.argv[2], sys.argv[3]
value = json.loads(value_json)
try:
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
except FileNotFoundError:
    data = {}

data.setdefault("patch", {})
data["patch"][key] = value

with open(path, "w", encoding="utf-8") as f:
    yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)
PYEOF
}

bopomo_patch_unset() {
  ensure_pyyaml
  python3 - "$BOPOMO_CUSTOM" "$1" << 'PYEOF'
import sys, yaml

path, key = sys.argv[1], sys.argv[2]
try:
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
except FileNotFoundError:
    data = {}

if "patch" in data and key in data["patch"]:
    del data["patch"][key]

with open(path, "w", encoding="utf-8") as f:
    yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)
PYEOF
}

bopomo_patch_has() {
  ensure_pyyaml
  python3 - "$BOPOMO_CUSTOM" "$1" << 'PYEOF'
import sys, yaml
path, key = sys.argv[1], sys.argv[2]
try:
    data = yaml.safe_load(open(path, encoding="utf-8")) or {}
except FileNotFoundError:
    data = {}
print("true" if key in data.get("patch", {}) else "false")
PYEOF
}

# 讀取「BackSpace 逐字刪除注音」目前狀態:on(已改成一次刪一個注音符號)/
# off(方案預設,候選字出現後一次刪整個字)/ missing(還沒裝洋蔥方案)
get_backspace_mode() {
  local schema="$RIME_DIR/bopomo_onion.schema.yaml"
  if [ ! -f "$schema" ]; then
    echo "missing"
  elif grep -q '^#關#[[:space:]]*- {accept: BackSpace, send: Control+BackSpace, when: has_menu}' "$schema"; then
    echo "on"
  elif grep -q '^[[:space:]]*- {accept: BackSpace, send: Control+BackSpace, when: has_menu}' "$schema"; then
    echo "off"
  else
    echo "missing"
  fi
}

# 切換「BackSpace 逐字刪除注音」,用法: set_backspace_mode on|off
set_backspace_mode() {
  local schema="$RIME_DIR/bopomo_onion.schema.yaml"
  [ -f "$schema" ] || return 1
  if [ "$1" = "on" ]; then
    sed -i '' 's/^\(    - {accept: BackSpace, send: Control+BackSpace, when: has_menu}.*\)$/#關#\1/' "$schema"
  else
    sed -i '' 's/^#關#\(    - {accept: BackSpace, send: Control+BackSpace, when: has_menu}.*\)$/\1/' "$schema"
  fi
}

# 一鍵移除:目標是讓「借用這台工具給別人試用」的人,用完後電腦能還原成用之前的樣子。
# 會刪掉這個工具建立的所有設定檔、洋蔥/倉頡方案本體、自訓語法模型、訓練資料夾、個人學習
# 記錄,也會盡量把 Squirrel 本身一併移除。squirrel.custom.yaml 只拿掉我們加的 3 個
# app_options,其他設定不動。不會動這幾個 App 檔案本身(那些請自己在 Finder 拖到垃圾桶)。
# 執行完會 echo 出結果摘要,呼叫端(action.sh)的輸出會被 GUI 拿來顯示給使用者看。
uninstall_all() {
  # -r 是必要的:bopomo_onion.userdb / cangjie5.userdb 是資料夾,也會被這個 glob 選到
  rm -rf "$RIME_DIR"/bopomo_onion.* "$RIME_DIR"/cangjie5.*
  rm -rf "$RIME_DIR"/build/bopomo_onion.* "$RIME_DIR"/build/cangjie5.* 2>/dev/null
  rmdir "$RIME_DIR/build" 2>/dev/null
  rm -rf "$RIME_DIR/userdb_backup"
  rm -f "$RIME_DIR/default.custom.yaml" "$RIME_DIR/custom_phrase.txt"
  rm -f "$RIME_DIR/grammar.custom.yaml" "$RIME_DIR/grammar.custom.yaml.disabled"

  if [ -f "$SQUIRREL_CUSTOM" ]; then
    ensure_pyyaml
    python3 - "$SQUIRREL_CUSTOM" << 'PYEOF'
import sys, yaml
path = sys.argv[1]
try:
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
except FileNotFoundError:
    data = {}
opts = data.get("patch", {}).get("app_options", {})
for bid in ("com.microsoft.VSCode", "com.apple.Terminal", "com.googlecode.iterm2"):
    opts.pop(bid, None)
with open(path, "w", encoding="utf-8") as f:
    yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)
PYEOF
  fi

  rm -rf "$LAB"

  # 盡量連 Squirrel 本身也移除。/Library 底下一般 admin 帳號通常不用密碼就能刪,
  # 但如果權限不夠(例如對方是標準帳號),就老實告訴使用者要自己手動刪。
  local squirrel_removed="no"
  local squirrel_left="no"
  for p in "/Library/Input Methods/Squirrel.app" "$HOME/Library/Input Methods/Squirrel.app"; do
    if [ -d "$p" ]; then
      if rm -rf "$p" 2>/dev/null; then
        squirrel_removed="yes"
      else
        squirrel_left="yes"
      fi
    fi
  done

  if [ "$squirrel_removed" = "yes" ] && [ "$squirrel_left" = "no" ]; then
    echo "已移除 Squirrel 本身。"
  elif [ "$squirrel_left" = "yes" ]; then
    echo "Squirrel 權限不足無法自動移除,請自己到「/Library/Input Methods/」把 Squirrel.app 拖到垃圾桶(會要求輸入密碼)。"
  else
    echo "這台電腦本來就沒有 Squirrel,或已經移除過了。"
  fi

  echo "最後一步(Apple 系統限制,無法自動化):打開「系統設定 > 鍵盤 > 輸入來源」,選取"
  echo "「中文(繁體) - 鼠鬚管」,按「-」移除,電腦就會回到用這個工具之前的狀態。"

  redeploy
}

# 洋蔥純注音方案內建的候選字前面會加 QY / AH 這種兩碼快選標籤(方案設計給熟手用二鍵
# 直選候選字),不想看到這排英文字母就換成純數字標籤
ONION_ALGEBRA_OFF='["xform/[)(]//", "xform/iu/iU/", "xform/ui/uI/", "xform/ong/ung/", "xform/yi?/i/", "xform/wu?/u/", "xform/iu/v/", "xform/([jqx])u/$1v/", "xform/([iuv])n/$1en/", "xform/zhi?/Z/", "xform/chi?/C/", "xform/shi?/S/", "xform/([zcsr])i/$1/", "xform/ai/A/", "xform/ei/I/", "xform/ao/O/", "xform/ou/U/", "xform/ang/K/", "xform/eng/G/", "xform/an/M/", "xform/en/N/", "xform/er/R/", "xform/eh/E/", "xform/([iv])e/$1E/", "abbrev/^([bpmfdtnlgkhjqxZCSrzcsiuvaoeEAIOUMNKGR]).+$/$1/", "abbrev/^([bpmfdtnlgkhjqxZCSrzcsiuv])([iuvaoeEAIOUMNKG])\\d$/$1$2/", "abbrev/^([bpmfdtnlgkhjqxZCSrzcs])([iuv])([aoeEAIOUMNKG])\\d$/$1$2$3/", "abbrev/^([bpmfdtnlgkhjqx]).+(\\d)$/$1$2/", "xform|^＊([12345])$|r$1|", "abbrev|^＊([bpmfdtnlgkhjqxZCSrzcsiuvaoeEAIOUMNKGR])$|$1|", "abbrev|^＊([bpmfdtnlgkhjqx])$|$1 |", "erase|^＊([bpmfdtnlgkhjqx])$||", "xform|^＊([ZCSrzcsiuvaoeEAIOUMNKGR])$|$1 |", "xform|^＊＊||", "xlit|bpmfdtnlgkhjqxZCSrzcsiuvaoeEAIOUMNKGR12345|1qaz2wsxedcrfv5tgbyhnujm8ik,9ol.0p;/- 6347|"]'

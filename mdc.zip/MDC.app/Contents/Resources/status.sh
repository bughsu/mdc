#!/bin/bash
# 印出目前四項開關的狀態,每行一個,給 GUI 控制面板讀取:on / off / missing
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SRC/functions.sh"

v="$(get_ascii_mode com.microsoft.VSCode)"
if [ "$v" = "true" ]; then echo "off"; else echo "on"; fi

t="$(get_ascii_mode com.apple.Terminal)"
if [ "$t" = "true" ]; then echo "off"; else echo "on"; fi

if [ -f "$RIME_DIR/grammar.custom.yaml" ]; then
  echo "on"
elif [ -f "$RIME_DIR/grammar.custom.yaml.disabled" ]; then
  echo "off"
else
  echo "missing"
fi

h="$(bopomo_patch_has "speller/algebra")"
if [ "$h" = "true" ]; then echo "off"; else echo "on"; fi

get_backspace_mode

#!/bin/bash
# 把語法模型 + 洋蔥注音方案本體內嵌進 App,打包成 zip
# 只把最後的 zip 路徑印到 stdout(GUI 控制面板要抓這個值),其他訊息都印到 stderr
set -e
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SRC/functions.sh"
APP_ROOT="$(cd "$SRC/../.." && pwd)"

if [ -f "$LAB/onion_combo.gram" ]; then
  cp "$LAB/onion_combo.gram" "$SRC/onion_combo.gram"
  echo "已把語法模型內嵌進 App" >&2
elif [ -f "$SRC/onion_combo.gram" ]; then
  echo "App 裡已經有內嵌語法模型,略過" >&2
else
  echo "找不到 ~/rime_grammar_lab/onion_combo.gram,打包版本將不含語法模型" >&2
fi

if [ -f "$RIME_DIR/bopomo_onion.schema.yaml" ]; then
  rm -rf "$SRC/rime_base"
  mkdir -p "$SRC/rime_base"
  rsync -a \
    --exclude 'build/' \
    --exclude '*.userdb/' \
    --exclude 'userdb_backup/' \
    --exclude 'installation.yaml' \
    --exclude 'squirrel.custom.yaml' \
    --exclude 'grammar.custom.yaml' \
    --exclude 'grammar.custom.yaml.disabled' \
    --exclude 'bopomo_onion.custom.yaml' \
    --exclude '*.gram' \
    --exclude 'default.custom.yaml' \
    --exclude 'custom_phrase.txt' \
    --exclude '*.log' \
    --exclude '.DS_Store' \
    "$RIME_DIR/" "$SRC/rime_base/"
  echo "已把洋蔥注音方案本體內嵌進 App" >&2
else
  echo "這台 Mac 還沒裝洋蔥注音方案本體,打包版本仍需要對方手動裝那一步" >&2
fi

ZIP_OUT="$HOME/Desktop/注音輸入法_分享版.zip"
rm -f "$ZIP_OUT"
ditto -c -k --sequesterRsrc --keepParent "$APP_ROOT" "$ZIP_OUT"
echo "$ZIP_OUT"

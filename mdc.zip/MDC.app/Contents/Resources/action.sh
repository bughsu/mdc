#!/bin/bash
# GUI 控制面板的動作分派器,用法: action.sh <動作名稱>
# 只有 package 這個動作要把結果(zip 路徑)印到 stdout 給 AppleScript 抓,其他動作
# 不需要輸出什麼
set -e
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SRC/functions.sh"

case "$1" in
  toggle_vscode)
    v="$(get_ascii_mode com.microsoft.VSCode)"
    if [ "$v" = "true" ]; then set_ascii_mode com.microsoft.VSCode false; else set_ascii_mode com.microsoft.VSCode true; fi
    redeploy
    ;;
  toggle_terminal)
    t="$(get_ascii_mode com.apple.Terminal)"
    if [ "$t" = "true" ]; then
      set_ascii_mode com.apple.Terminal false
      set_ascii_mode com.googlecode.iterm2 false
    else
      set_ascii_mode com.apple.Terminal true
      set_ascii_mode com.googlecode.iterm2 true
    fi
    redeploy
    ;;
  toggle_grammar)
    if [ -f "$RIME_DIR/grammar.custom.yaml" ]; then
      mv "$RIME_DIR/grammar.custom.yaml" "$RIME_DIR/grammar.custom.yaml.disabled"
    elif [ -f "$RIME_DIR/grammar.custom.yaml.disabled" ]; then
      mv "$RIME_DIR/grammar.custom.yaml.disabled" "$RIME_DIR/grammar.custom.yaml"
    fi
    redeploy
    ;;
  toggle_order)
    if [ "$(bopomo_patch_has "speller/algebra")" = "true" ]; then
      bopomo_patch_unset "speller/algebra"
    else
      bopomo_patch_set "speller/algebra" "$ONION_ALGEBRA_OFF"
    fi
    redeploy
    ;;
  toggle_backspace)
    if [ "$(get_backspace_mode)" = "on" ]; then
      set_backspace_mode off
    else
      set_backspace_mode on
    fi
    redeploy
    ;;
  reset_userdb)
    mkdir -p "$RIME_DIR/userdb_backup"
    mv "$RIME_DIR"/*.userdb "$RIME_DIR/userdb_backup/" 2>/dev/null || true
    redeploy
    ;;
  package)
    bash "$SRC/package.sh"
    ;;
  uninstall)
    uninstall_all
    ;;
  redeploy)
    redeploy
    ;;
  *)
    echo "未知的動作: $1" >&2
    exit 1
    ;;
esac

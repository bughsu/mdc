#!/bin/bash
# 一次性同步:安裝 Squirrel、放入設定檔、掛語法模型、重新部署
# 由 GUI 控制面板(AppleScript)在第一次開啟時呼叫,也可以自己直接跑
set -e

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SRC/functions.sh"

LOG="$HOME/rime_grammar_lab/sync.log"
mkdir -p "$HOME/rime_grammar_lab"
exec > >(tee -a "$LOG") 2>&1
echo "===== $(date) ====="

# 1. Homebrew(GUI 面板沒有終端機視窗,沒辦法互動輸入密碼,裝 Homebrew 需要的 sudo
#    密碼只能在真正的 Terminal 裡輸入,所以這裡只檢查,不自動裝)
if ! command -v brew >/dev/null 2>&1; then
  echo "[1/7] 找不到 Homebrew"
  echo "      GUI 面板沒辦法輸入密碼,請自己開一次「終端機」App,貼上這行跑完後"
  echo "      再重開這個 GUI:"
  echo "      /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
  exit 1
else
  echo "[1/7] Homebrew 已安裝,略過"
fi

# 2. Squirrel
echo "[2/7] 檢查 Squirrel..."
if [ -d "/Library/Input Methods/Squirrel.app" ] || [ -d "$HOME/Library/Input Methods/Squirrel.app" ]; then
  echo "      已安裝,略過"
else
  brew install --cask squirrel
fi

# 3. 洋蔥注音方案本體
echo "[3/7] 檢查洋蔥注音方案..."
if [ -f "$RIME_DIR/bopomo_onion.schema.yaml" ]; then
  echo "      已經裝過,略過"
elif [ -d "$SRC/rime_base" ]; then
  echo "      App 內附方案本體,直接安裝..."
  cp -R "$SRC/rime_base/." "$RIME_DIR/"
else
  echo "      !! 尚未偵測到洋蔥注音方案,需要手動裝一次,詳見安裝指南步驟 1 !!"
fi

# 4. 放入自訂設定檔 + 候選字標籤換成純數字
echo "[4/7] 放入自訂設定檔..."
cp "$SRC/default.custom.yaml" "$RIME_DIR/"
if [ ! -f "$RIME_DIR/custom_phrase.txt" ]; then
  cp "$SRC/custom_phrase.txt" "$RIME_DIR/"
fi
bopomo_patch_set "menu/alternative_select_labels" '["1", "2", "3", "4", "5", "6", "7", "8"]'

# 5. 允許 VS Code / Terminal / iTerm 打中文
echo "[5/7] 開啟 VS Code / Terminal / iTerm 中文輸入..."
set_ascii_mode "com.microsoft.VSCode" false
set_ascii_mode "com.apple.Terminal" false
set_ascii_mode "com.googlecode.iterm2" false

# 6. 語法模型
echo "[6/7] 檢查自訓語法模型..."
if [ -f "$SRC/onion_combo.gram" ]; then
  cp "$SRC/onion_combo.gram" "$RIME_DIR/"
  cp "$SRC/grammar.custom.yaml" "$RIME_DIR/"
  echo "      已放入 App 內附的語法模型"
elif [ -f "$LAB/onion_combo.gram" ]; then
  cp "$LAB/onion_combo.gram" "$RIME_DIR/"
  cp "$SRC/grammar.custom.yaml" "$RIME_DIR/"
  echo "      已放入 onion_combo.gram"
elif [ -f "$LAB/onion_wiki.gram" ]; then
  cp "$LAB/onion_wiki.gram" "$RIME_DIR/"
  sed 's/language: onion_combo/language: onion_wiki/' "$SRC/grammar.custom.yaml" > "$RIME_DIR/grammar.custom.yaml"
  echo "      找到舊版 onion_wiki.gram,先用這個"
else
  echo "      找不到自訓語法模型,略過"
fi

# 7. 重新部署 + 開啟輸入來源設定
echo "[7/7] 重新部署..."
redeploy
open "x-apple.systempreferences:com.apple.preference.keyboard?InputSources" 2>/dev/null || true
echo "同步完成"
